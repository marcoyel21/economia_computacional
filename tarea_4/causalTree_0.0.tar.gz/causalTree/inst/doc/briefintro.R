### R code from vignette source 'briefintro.Rnw'

###################################################
### code chunk number 1: example1
###################################################
library(causalTree)
tree <- causalTree(y ~ x1 + x2 + x3 + x4, data = simulation.1, 
                  treatment = simulation.1$treatment, split.Rule = "TOT",
                  cv.option = "fit", cv.Honest = F, split.Bucket = T, 
                  xval = 10, cv.alpha = 0.5, propensity = 0.5)
rpart.plot(tree)


###################################################
### code chunk number 2: example2
###################################################
tree <- causalTree(y ~ x1 + x2 + x3 + x4, data = simulation.1, 
                  treatment = simulation.1$treatment, split.Rule = "CT",
                  split.Honest = T, cv.option = "matching", cv.Honest = F, 
                  split.Bucket = F, xval = 10)
tree$cptable
rpart.plot(tree)


###################################################
### code chunk number 3: prune
###################################################
opcp <- tree$cptable[, 1][which.min(tree$cptable[,4])]
optree <- prune(tree, cp = opcp)
rpart.plot(optree)


###################################################
### code chunk number 4: example3
###################################################
n <- nrow(simulation.1)

trIdx <- which(simulation.1$treatment == 1)

conIdx <- which(simulation.1$treatment == 0)

train_idx <- c(sample(trIdx, length(trIdx) / 2), 
               sample(conIdx, length(conIdx) / 2))

train_data <- simulation.1[train_idx, ]

est_data <- simulation.1[-train_idx, ]

honestTree <- honest.causalTree(y ~ x1 + x2 + x3 + x4, data = train_data,
                                treatment = train_data$treatment, 
                                est_data = est_data, 
                                est_treatment = est_data$treatment, 
                                split.Rule = "CT", split.Honest = T, 
                                HonestSampleSize = nrow(est_data), 
                                split.Bucket = T, cv.option = "fit",
                                cv.Honest = F)
                                
opcp <-  honestTree$cptable[,1][which.min(honestTree$cptable[,4])]

opTree <- prune(honestTree, opcp)

rpart.plot(opTree)


